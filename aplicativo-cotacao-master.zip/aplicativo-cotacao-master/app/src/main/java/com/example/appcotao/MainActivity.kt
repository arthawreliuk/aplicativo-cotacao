package com.example.appcotao

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.example.appcotao.ui.MainScreen
import com.example.appcotao.ui.theme.AppCotaçãoTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            AppCotaçãoTheme {
                MainScreen()
            }
        }
    }
}