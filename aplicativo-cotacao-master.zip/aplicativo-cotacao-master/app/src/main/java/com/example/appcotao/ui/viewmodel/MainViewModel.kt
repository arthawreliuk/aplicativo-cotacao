package com.example.appcotao.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.appcotao.data.model.ConversionResponse
import com.example.appcotao.data.remote.RetrofitClient
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class MainViewModel : ViewModel() {

    private val _currencies = MutableStateFlow<Map<String, String>>(emptyMap())
    val currencies = _currencies.asStateFlow()

    private val _conversionResult = MutableStateFlow<ConversionResponse?>(null)
    val conversionResult = _conversionResult.asStateFlow()

    init {
        viewModelScope.launch {
            fetchCurrencies()
        }
    }

    private suspend fun fetchCurrencies() {
        try {
            _currencies.value = RetrofitClient.instance.getCurrencies()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun convert(amount: Double, from: String, to: String) {
        viewModelScope.launch {
            try {
                _conversionResult.value = RetrofitClient.instance.getLatestRates(amount, from, to)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
}