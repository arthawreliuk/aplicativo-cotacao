package com.example.appcotao.data.remote

import com.example.appcotao.data.model.ConversionResponse
import retrofit2.http.GET
import retrofit2.http.Query

interface ApiService {
    @GET("currencies")
    suspend fun getCurrencies(): Map<String, String>

    @GET("latest")
    suspend fun getLatestRates(
        @Query("amount") amount: Double,
        @Query("from") from: String,
        @Query("to") to: String
    ): ConversionResponse
}