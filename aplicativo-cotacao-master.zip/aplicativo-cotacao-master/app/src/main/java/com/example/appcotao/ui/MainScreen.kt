package com.example.appcotao.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.appcotao.ui.viewmodel.MainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(viewModel: MainViewModel = viewModel()) {
    val currencies by viewModel.currencies.collectAsState()
    val conversionResult by viewModel.conversionResult.collectAsState()

    var fromCurrency by remember { mutableStateOf<String?>(null) }
    var toCurrency by remember { mutableStateOf<String?>(null) }
    var amount by remember { mutableStateOf("") }

    LaunchedEffect(currencies) {
        if (fromCurrency == null && currencies.isNotEmpty()) {
            fromCurrency = currencies.keys.firstOrNull()
        }
        if (toCurrency == null && currencies.isNotEmpty()) {
            toCurrency = currencies.keys.drop(1).firstOrNull() ?: currencies.keys.firstOrNull()
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        if (currencies.isEmpty()) {
            CircularProgressIndicator()
            Text(text = "Carregando moedas...")
        } else {
            CurrencyDropDown(
                label = "De",
                options = currencies.keys.toList(),
                selectedOption = fromCurrency ?: "",
                onOptionSelected = { fromCurrency = it }
            )

            CurrencyDropDown(
                label = "Para",
                options = currencies.keys.toList(),
                selectedOption = toCurrency ?: "",
                onOptionSelected = { toCurrency = it }
            )

            OutlinedTextField(
                value = amount,
                onValueChange = { amount = it.filter { char -> char.isDigit() || char == '.' } },
                label = { Text("Valor") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            
            Spacer(modifier = Modifier.height(8.dp))

            Button(
                onClick = {
                    val amountValue = amount.toDoubleOrNull()
                    if (amountValue != null && fromCurrency != null && toCurrency != null) {
                        viewModel.convert(amountValue, fromCurrency!!, toCurrency!!)
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("CONVERTER")
            }
            
            Spacer(modifier = Modifier.height(8.dp))

            conversionResult?.let { result ->
                val rate = result.rates.entries.firstOrNull()
                if (rate != null) {
                    Text(
                        text = "Resultado: ${rate.value} ${rate.key}",
                        style = MaterialTheme.typography.headlineSmall
                    )
                }
            }
        }
    }
}


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CurrencyDropDown(
    label: String,
    options: List<String>,
    selectedOption: String,
    onOptionSelected: (String) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }

    ExposedDropdownMenuBox(
        expanded = expanded,
        onExpandedChange = { expanded = !expanded }
    ) {
        OutlinedTextField(
            value = selectedOption,
            onValueChange = {},
            readOnly = true,
            label = { Text(label) },
            trailingIcon = {
                ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded)
            },
            modifier = Modifier.menuAnchor().fillMaxWidth(),
            colors = ExposedDropdownMenuDefaults.textFieldColors()
        )
        ExposedDropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false }
        ) {
            options.forEach { option ->
                DropdownMenuItem(
                    text = { Text(option) },
                    onClick = {
                        onOptionSelected(option)
                        expanded = false
                    }
                )
            }
        }
    }
}