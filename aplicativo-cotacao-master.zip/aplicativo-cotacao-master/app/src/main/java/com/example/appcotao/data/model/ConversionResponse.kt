package com.example.appcotao.data.model

data class ConversionResponse(
    val amount: Double,
    val base: String,
    val date: String,
    val rates: Map<String, Double>
)
