Este é um simples aplicativo de cotação moedas utilizando a API: https://www.frankfurter.app/docs/

[App Cotação Descrição.pdf](https://github.com/user-attachments/files/23587323/App.Cotacao.Descricao.pdf)
